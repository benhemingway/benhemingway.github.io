%{
Example code 2 for Introduction to MATLAB course.
Author: Benjamin Hemingway, Bank of Lithuanian and Vilnius University
Date: 13Nov2019

This code simulates the rolling of two fair dice and plots the frequency of the totals.
%}
clear % clear any variables in the workspace
clc % clear any text in the command window

% Set parameters
N = 1000; % number of rolls

% Generate random draws
unif_rand = rand(N,2); % uniform random draws for two dice

% Create (empty) matrix of rolls
rolls_d = int8(zeros(N,2)); 
%{ 
Note: the rolls can only take integer values between 1 and 6
while the totals will only take integer values between 2 and12
We can save memory by using int8() for these vectors
Using integers will also help with using == 
%}

% Converts the random draws into die outcome
for i=1:N % loop over each random draw
    for j=1:2 % loop over each die
        if unif_rand(i,j)<1/6
            rolls_d(i,j)=int8(1);
        elseif unif_rand(i,j)<2/6
            rolls_d(i,j)=int8(2);
        elseif unif_rand(i,j)<3/6
            rolls_d(i,j)=int8(3);
        elseif unif_rand(i,j)<4/6
            rolls_d(i,j)=int8(4);
        elseif unif_rand(i,j)<5/6
            rolls_d(i,j)=int8(5);
        else
            rolls_d(i,j)=int8(6);
        end
    end
end

% add the two columns (dice) together to generate totals
rolls_total = sum(rolls_d,2); % Nx1 column vector

% Note that value of rolls will go from 2 to 12 (use int8)
value = int8(2:1:12);

% create a vector for the frequency of each 
freq = zeros(size(value)); % same size and shape vector as total

% Now we can use a loop to calculate the frequency
for i=1:length(value) % use length() or size() to iterate over every element
    freq(i) = sum(rolls_total==value(i));
end

% calculate the estimated probability
prob = freq./N;

% create a bar chart
bar(double(value),prob) % Octave doesn't like plotting integers, so convert back to double-precision float
xlabel('Total'); % labels x-axis
ylabel('Proportion of rolls'); % labels y-axis
title('Monte Carlo: Two dice rolls'); % adds a title

disp('End of script')