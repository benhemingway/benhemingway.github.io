%{
Example code 4 for Introduction to MATLAB course.
Author: Benjamin Hemingway, Bank of Lithuanian and Vilnius University
Date: 20Nov2018

This code solves a simple RBC model using dynamic programming
%}
clear % clear any variables in the workspace
clc % clear any text in the command window


disp('End of script')