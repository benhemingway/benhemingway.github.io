function out = rosenbrock(x,y,a)
   out = (a-x).^2 + 100*(y-x.^2).^2;  % minimum at (a,a.^2)
end
