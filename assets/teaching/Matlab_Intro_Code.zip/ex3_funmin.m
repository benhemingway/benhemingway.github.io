%{
Example code 3 for Introduction to MATLAB course.
Author: Benjamin Hemingway, Bank of Lithuanian and Vilnius University
Date: 13Nov2019

This code illustrates how one might approach minimizing nonlinear functions.
The rosenbrock function with 
%}
clear % clear any variables in the workspace
clc % clear any text in the command window

% set parameters of the problem
a = 1.0;
true_min = [a,a.^2];
N = 25; 

%{ 
NOTE: octave-online.net has restrictions on the size of graphs.
Thus I have limited  N=25 to ensure the graph can be shown.
%}

% 1) Create rosenbrock function script
% see: rosenbrock.m

% 2) Create vector of length B
x1 = linspace(-2,2,N);
x2 = linspace(-1,3,N);

% 3) use a loop to create a matrix (N,N) where y=rosenbrock(x1,x2,a)
y = zeros(N,N);

for i=1:N
  for j=1:N
     y(i,j) = rosenbrock(x1(j),x2(i),a);
  end
end

% plot using mesh
mesh(x1,x2,y) % 3D plot of rosenbrock function
xlabel('x1'); % labels x-axis
ylabel('x2'); % labels y-axis
zlabel('y'); % labels z-axis
title('Rosenbrock function (a=1)'); % adds a title


% 4) find the (x1,x2) that yields the minimum value of y
miny_grid = min(min(y));
[I2,I1] = find(miny_grid==y);
x1min = x1(I1);
x2min = x2(I2);

% 5) use fsolve to find the minimum, using your previous answer as a starting point
fun = @(x)rosenbrock(x(1),x(2),a);
x0 = [x1min,x2min];
[xmin,ymin] = fminsearch(fun,x0);

% 6) now use a starting point of (200,200) 
[xmin2,ymin2] = fminsearch(fun,[200,200]);

% 7) print results
fprintf('Minimum found using grid: %e @(%4.2f,%4.2f)\n',miny_grid,x1min,x2min);
fprintf('Minimum found using fminsearch (1st attempt): %e @(%4.2f,%4.2f)\n',ymin,xmin(1),xmin(2));
fprintf('Minimum found using fminsearch (2nd attempt): %4.2f @(%4.2f,%4.2f)\n',ymin2,xmin2(1),xmin2(2));

disp('End of script')