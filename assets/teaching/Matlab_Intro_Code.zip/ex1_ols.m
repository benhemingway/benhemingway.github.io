%{
Example code 1 for Introduction to MATLAB course.
Author: Benjamin Hemingway, Bank of Lithuanian and Vilnius University
Date: 20Nov2018

This code generates some 'data' and runs an OLS regression
%}
clear % clear any variables in the workspace
clc % clear any text in the command window

N = 1000; % defines the number of "observations"
sig=0.1; % defines the standard deviation of epsilon

% Create Simulated dataset
x_sim = [ones(N,1),rand(N,3)]; % creates a matrix of explanatory variables
b=rand(4,1); % creates a vector of "true" coefficients
epsilon = sig.*randn(N,1); % creates a vector of residuals
y_sim = x_sim*b + epsilon; % creates the dependant variable
dataGrid = [y_sim x_sim(:,2:4)]; % create matrix with data to save

% save simulated data (as csv)
dataSave = fopen('ols_data.csv','w'); % creates a new file
fprintf(dataSave,'%s,%s,%s,%s\n','Y','X1','X2','X3'); % writes to text file
fprintf(dataSave,'%f,%f,%f,%f\n',dataGrid'); % Note transpose here
fclose(dataSave); % need to remember to text file

% load simulated data
filename = 'ols_data.csv'; % let matlab know which file to load
delimiterIn = ','; % tells matlab how data is separated
headerlinesIn = 1; % tells matlab how many rows are headers in the data
ols_data = importdata(filename,delimiterIn,headerlinesIn); % loads data as a structure

% convert cell data to matrix form
y = ols_data.data(:,1); % first column is the dependent variable
y_lab = ols_data.colheaders{1}; % label for dependent variable
x = [ones(N,1),ols_data.data(:,2:end)]; % explanatory variables
x_lab = ols_data.colheaders(2:4); % label for independent variables

% estimate OLS
bhat = (x'*x)\(x'*y); % OLS formula

% print coefficients to window
fprintf('Estimated OLS for sample size N=%d\n',N);
fprintf('%7s %7s\n','b','bhat'); % The %9s is set to the length of the longest word
fprintf('%7.5f %7.5f\n',[b bhat]'); % prints the true and estimated vectors of coefficients

% Save true and estimated coefficients as a text file
fileSave = fopen('ols_output.txt','w'); % creates a new file
fprintf(fileSave,'%7s %7s\n','b','bhat'); % writes to text file
fprintf(fileSave,'%7.5f %7.5f\n',[b bhat]'); % writes to text file
fclose(fileSave); % need to remember to text file

err = norm(b-bhat); % calculates the L2 (euclidian norm)
fprintf('\nL2 norm between true and estimated coefficients = %f\n',err);

disp('End of script');